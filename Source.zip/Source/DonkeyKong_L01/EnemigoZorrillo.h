// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemigo.h"
#include "EnemigoZorrillo.generated.h"

/**
 * 
 */
UCLASS()
class DONKEYKONG_L01_API AEnemigoZorrillo : public AEnemigo
{
	GENERATED_BODY()
	
};
