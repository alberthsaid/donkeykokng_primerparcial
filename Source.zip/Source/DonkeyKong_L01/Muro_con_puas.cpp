// Fill out your copyright notice in the Description page of Project Settings.


#include "Muro_con_puas.h"

// Sets default values
AMuro_con_puas::AMuro_con_puas()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AMuro_con_puas::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AMuro_con_puas::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

