// Copyright Epic Games, Inc. All Rights Reserved.

#include "DonkeyKong_L01.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, DonkeyKong_L01, "DonkeyKong_L01" );
 